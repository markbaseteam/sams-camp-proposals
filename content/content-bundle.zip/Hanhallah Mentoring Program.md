The Hanhallah Mentoring Program (HMP) will focus on shaping interested staff (3<sup>rd</sup> year+) into the best Hanhallah members they can be. It can act as a pipeline to develop the next generation of Hanhallah members.

```ccard
items: [
  {
    title: 'FAQ',
    link: 'Proposals/Hanhallah Mentoring Program/FAQ.md',
    brief: '%%',
    foot: '10/26/2022, 9:24:28 PM',
    head: 'Note'
  },
  {
    title: 'Midprogram Reflection',
    link: 'Proposals/Hanhallah Mentoring Program/Midprogram Reflection.md',
    brief: 'No abstract.',
    foot: '8/2/2022, 5:09:52 PM',
    head: 'Note'
  },
  {
    title: 'Proposal with Jareds Feedback',
    link: 'Proposals/Hanhallah Mentoring Program/Proposal with Jareds Feedback.md',
    brief: '- #General Breakdown|General Breakdown',
    foot: '10/26/2022, 9:24:33 PM',
    head: 'Note'
  },
  {
    title: 'Proposal',
    link: 'Proposals/Hanhallah Mentoring Program/Proposal.md',
    brief: '- #General Breakdown|General Breakdown',
    foot: '10/26/2022, 6:11:08 PM',
    head: 'Note'
  },
  {
    title: 'Schedule',
    link: 'Proposals/Hanhallah Mentoring Program/Schedule.md',
    brief: '- #Week 1|Week 1',
    foot: '8/27/2022, 8:18:08 PM',
    head: 'Note'
  },
  {
    title: 'Sessions',
    link: 'Proposals/Hanhallah Mentoring Program/Sessions.md',
    brief: '- #How to Effectivly Lead/Leadership @ Camp|How to Effectivly Le...',
    foot: '8/12/2022, 5:36:25 PM',
    head: 'Note'
  }
]
```