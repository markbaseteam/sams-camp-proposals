- [[#General Breakdown|General Breakdown]]
- [[#Learning Goals|Learning Goals]]
- [[#Session Ideas|Session Ideas]]
- [[#Midprogram Reflection|Midprogram Reflection]]
- [[#Links|Links]]

The Hanhallah Mentoring Program (HMP) will focus on shaping interested staff (3<sup>rd</sup> year+) into the best Hanhallah members they can be. It can act as a pipeline to develop the next generation of Hanhallah members.

----------

## General Breakdown
- start off the summer doing one learning session a week (on leadership and operation of camp).
- after TBD# sessions mentees will start shadowing their Rosh Anaf (for specialists) or AUH (for Counselors). This will obviously be pending coverage in cabin or activity area. 
- after TBD# weeks of shadowing mentees start covering for Rosh Anaf or AUH when mentor is on their doff.
- Mid-program Reflection at some point around changeover
- Weekly check-in meeting with mentor
- (maybe) plan an execute an all-camp program ==as a group==

------

## Learning Goals
- Gaining an intimate knowledge of how camp works
- build skills in leadership and team management
- learn responsibilities of each Hanhallah role

--------


%%
## 

%%
## Session Ideas
|     |     |
| --- | --- |
| \- How to Effectivly Lead <br> - Leadership @ Camp | \- Responsabilities <br> - Pre-summer Responsabilities |
| | \- From Camper-Staff Dynamics To Staff-Superviser Dynamics: <br> How to Manage with Your Staff |

-----

%% ## [[Mid-program Reflection]] %%
## Mid-program Reflection

As implied by the title this would be a (one on one) reflection guided by the mentor. This is a reflection not an evaluation which means that it would be from the mentees perspective and shouldn't be used in the hiring process (but can be retained for the purposes of improving the program).

## Process to Join the Program

^96afa9

Staff members can either be invited to join by Admin before the summer or sign up during staff week. ^866609
%%
```button
name Midprogram Reflection
type link
action obsidian://open?vault=Camp&file=Hanhallah%20Mentoring%20Program%2FMidprogram%20Reflection
```
^button-l5hf
%%

## Links
- [[FAQ]]
- [[Mid-program Reflection]]
- [[Schedule]]
- [[Sessions]]